/** Automatically generated file. DO NOT MODIFY */
package com.zing.snakeclassic;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}